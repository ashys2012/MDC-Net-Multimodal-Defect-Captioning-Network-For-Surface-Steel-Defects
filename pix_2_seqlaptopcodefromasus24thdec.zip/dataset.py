'''
THis code takes in single bbox dataset and converts it into dataframe that is specified in the 
https://colab.research.google.com/drive/1UeYIZ6_GHNwCHSi8nNV5dVc3oUrM5-BA?usp=sharing#scrollTo=knCEq7-qLAZZ

THis code works and is used for Pix2Seq


'''
import albumentations as A
from sklearn.model_selection import StratifiedGroupKFold
import pandas as pd
import os
import torch
from torch.nn.utils.rnn import pad_sequence


# To display all columns
pd.set_option('display.max_columns', None)

# To display all rows
pd.set_option('display.max_rows', None)

# To display the entire contents of each cell (useful for large strings)
pd.set_option('display.max_colwidth', None)


import os
import pandas as pd

def txt_file_to_df(txt_file_path, image_folder):
    ids = []
    labels = []
    xmin = []
    ymin = []
    xmax = []
    ymax = []
    img_paths = []
    
    defect_mapping = {
        'crazing': 0,
        'inclusion': 1,
        'patches': 2,
        'pitted_surface': 3,
        'rolled-in_scale': 4,
        'scratches': 5
    }
    
    with open(txt_file_path, 'r') as f:
        lines = f.readlines()
        for line in lines:
            parts = line.strip().split(',')
            image_name = parts[0]
            
            # Extracting defect type from the image name
            parts_of_name = image_name.split('_')
            defect_type = '_'.join(parts_of_name[:-1])  # Join all parts except the last one
            
            # Extract the label from the current part
            label = int(parts[2])
            
            # Extract the coordinates from the current part
            coords = list(map(int, parts[3:]))
            
            unique_id = f"{defect_type}_{parts_of_name[-1].split('.')[0]}"
            ids.append(unique_id)
            
            labels.append(label)  # Use the extracted label here
            xmin.append(coords[0])
            ymin.append(coords[1])
            xmax.append(coords[2])
            ymax.append(coords[3])
            img_paths.append(os.path.join(image_folder, image_name))
            
    df = pd.DataFrame({
        'id': ids,
        'label': labels,
        'xmin': xmin,
        'ymin': ymin,
        'xmax': xmax,
        'ymax': ymax,
        'img_path': img_paths
    })
    #print("this is the main df ----------", df.head(5))
    return df


from sklearn.model_selection import train_test_split

def split_train_valid(df, test_size=0.2, random_state=42):
    """
    Splits the given dataframe into training and validation sets based on unique IDs.

    Parameters:
    - df: The input dataframe
    - test_size: Fraction of the data to reserve as the validation set
    - random_state: Random seed for reproducibility

    Returns:
    - train_df: Training dataframe
    - valid_df: Validation dataframe
    """
    train_df, valid_df = train_test_split(df, test_size=test_size, random_state=random_state)
    return train_df, valid_df


def get_transform_train(size):
    return A.Compose([
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.5),
        A.Rotate(limit=30, p=0.5),
        A.RandomBrightnessContrast(p=0.2),
        A.GaussianBlur(blur_limit=(3, 7), p=0.5),
        A.MotionBlur(blur_limit=3, p=0.5),
        #A.ElasticTransform(alpha=1, sigma=50, alpha_affine=50, p=0.5),
        #A.GridDistortion(p=0.5),
        #A.RandomResizedCrop(height=size, width=size, scale=(0.8, 1.0), p=0.5),
        A.Resize(size, size),
        A.Normalize(),
    ], bbox_params={'format': 'pascal_voc', 'label_fields': ['labels']})




def get_transform_valid(size):
    return A.Compose([
        A.Resize(size, size),
        A.Normalize(),
    ], bbox_params={'format': 'pascal_voc', 'label_fields': ['labels']})





def collate_fn(batch, max_len, pad_idx):
    """
    if max_len:
        the sequences will all be padded to that length
    """
    image_batch, seq_batch = [], []
    for image, seq in batch:
        image_batch.append(image)
        seq_batch.append(seq)

    seq_batch = pad_sequence(
        seq_batch, padding_value=pad_idx, batch_first=True)
    if max_len:
        pad = torch.ones(seq_batch.size(0), max_len -
                         seq_batch.size(1)).fill_(pad_idx).long()
        seq_batch = torch.cat([seq_batch, pad], dim=1)
    image_batch = torch.stack(image_batch)
    return image_batch, seq_batch



# def check_bbox_coordinates(txt_file_path):
#     incorrect_lines = []
    
#     with open(txt_file_path, 'r') as f:
#         lines = f.readlines()
#         for line in lines:
#             parts = line.strip().split(',')
#             xmin, ymin, xmax, ymax = map(int, parts[-4:])
            
#             if xmax <= xmin or ymax <= ymin:
#                 incorrect_lines.append(line.strip())
                
#     if incorrect_lines:
#         print("Lines with incorrect bounding box coordinates:")
#         for line in incorrect_lines:
#             print(line)
#     else:
#         print("All bounding box coordinates are correct.")



# if __name__ == '__main__':
#     txt_file_path = '/home/w19034038/Documents/workspace_trial/one_dd/pix2seq/data/full_neu_bbox_no_captions/annotations.txt'  # Replace with the path to your text file
#     check_bbox_coordinates(txt_file_path)
    
    # Your existing code for data loading, training, etc.



# if __name__ == "__main__":
#     print("Names inside the module:", dir())
