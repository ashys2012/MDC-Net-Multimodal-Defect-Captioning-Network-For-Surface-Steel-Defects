import os
from dataset import txt_file_to_df, get_transform_train, get_transform_valid, collate_fn
from allied_files import seed_everything, CFG, Tokenizer
from model import Encoder, Decoder, EncoderDecoder
import torch
import cv2
from functools import partial
from sklearn.model_selection import train_test_split
from utils import AvgMeter, get_lr
from tqdm import tqdm
from torch import nn
import transformers
from transformers import top_k_top_p_filtering
from transformers import get_linear_schedule_with_warmup
import matplotlib.pyplot as plt
seed_everything(seed=42)
#import wandb
#wandb.init(project="pix_2_seq")



txt_file_path = "/home/achazhoor/Documents/workspace/pix_2_seq/data/annotations_train.txt"
image_folder = "pix_2_seq/data/IMAGES"

df = txt_file_to_df(txt_file_path, image_folder)  # Assuming you've already created df using txt_file_to_df
# Add '.jpg' extension to image paths that don't have it
df['img_path'] = df['img_path'].apply(lambda x: x if x.lower().endswith('.jpg') else f"{x}.jpg")

print(df.head(5))
print("The length of df is ",len(df))

def is_valid_bbox(x_min, y_min, x_max, y_max):
    return x_max > x_min and y_max > y_min

def check_bbox_validity(bboxes):
    for bbox in bboxes:
        xmin, ymin, xmax, ymax = bbox[:4]
        if xmax <= xmin or ymax <= ymin:
            return False, f"Invalid bbox: {bbox}"
    return True, "All bboxes are valid."

# Extract bounding box data from the DataFrame
bounding_boxes = df[['xmin', 'ymin', 'xmax', 'ymax']].values

# Check the validity of the bounding boxes
validity, message = check_bbox_validity(bounding_boxes)
print(message)

# If you want to check each bounding box individually
for bbox in bounding_boxes:
    if not is_valid_bbox(*bbox):
        print(f"Invalid bbox: {bbox}")


class VOCDataset(torch.utils.data.Dataset):
    def __init__(self, df, transforms=None, tokenizer=None):
        self.ids = df['id'].unique()
        self.df = df
        self.transforms = transforms
        self.tokenizer = tokenizer

    def __getitem__(self, idx):
        sample = self.df[self.df['id'] == self.ids[idx]]
        img_path = sample['img_path'].values[0]

        img = cv2.imread(img_path)[..., ::-1]
        labels = sample['label'].values
        bboxes = sample[['xmin', 'ymin', 'xmax', 'ymax']].values  # Make sure only these columns are selected

        #print("Before transformation:", bboxes)
        if self.transforms is not None:
            transformed = self.transforms(**{
                'image': img,
                'bboxes': bboxes,
                'labels': labels
            })
            img = transformed['image']
            bboxes = transformed['bboxes']
            labels = transformed['labels']
        
        #print("After transformation:", bboxes)
        
        # Check if bounding boxes are still valid after transformations
        is_valid, message = check_bbox_validity(bboxes)
        if not is_valid:
            print(message)
            raise ValueError(message)

        #THe below code converts to pytorch tensor and PyTorch's CNNs expect CHW format
        img = torch.FloatTensor(img).permute(2, 0, 1)

        for bbox in bboxes:
            x_min, y_min, x_max, y_max = bbox
            if not is_valid_bbox(x_min, y_min, x_max, y_max):
                print(f"Invalid bbox: {bbox}")
                # Handle the invalid bbox (skip it, correct it, or raise an error)

        if self.tokenizer is not None:
            seqs = self.tokenizer(labels, bboxes)
            seqs = torch.LongTensor(seqs)
            return img, seqs        # seq contains both labels and bboxes

        return img, labels, bboxes

    def __len__(self):
        return len(self.ids)
    

tokenizer = Tokenizer(num_classes=6, num_bins=CFG.num_bins,
                          width=CFG.img_size, height=CFG.img_size, max_len=CFG.max_len)
CFG.pad_idx = tokenizer.PAD_code

def get_loaders(df, tokenizer, img_size, batch_size, max_len, pad_idx, num_workers=2, valid_size=0.2):
    
    # Split the original data into train and validation dataframes
    train_df, valid_df = train_test_split(df, test_size=valid_size, random_state=42)

    print("training dataset is ", len(train_df))
    print("val dataset is ", len(valid_df))
    
    train_ds = VOCDataset(train_df, transforms=get_transform_train(img_size), tokenizer=tokenizer)
    valid_ds = VOCDataset(valid_df, transforms=get_transform_valid(img_size), tokenizer=tokenizer)
    
    #THe below code is to check the dataset with its bbox
    #
    num_samples_to_print = 5

    for i in range(num_samples_to_print):
        # Get the ith sample
        img_tensors, bbox_label_seq = train_ds[i]  # Unpack the tuple here
        
        # Print the bounding boxes and labels
        print(f"Sample {i}:")
        print("Img_tensors:", img_tensors)
        print("Seq:", bbox_label_seq)
        print("\n")


    train_loader = torch.utils.data.DataLoader(
        train_ds,
        batch_size=batch_size,
        shuffle=True,
        collate_fn=partial(collate_fn, max_len=max_len, pad_idx=pad_idx),
        num_workers=num_workers,
        pin_memory=True,
    )
    
    valid_loader = torch.utils.data.DataLoader(
        valid_ds,
        batch_size=batch_size,
        shuffle=False,
        collate_fn=partial(collate_fn, max_len=max_len, pad_idx=pad_idx),
        num_workers=num_workers,
        pin_memory=True,
    )

    print("Train size: ", train_df['id'].nunique())
    print("Valid size: ", valid_df['id'].nunique())
        
    return train_loader, valid_loader  # Removed test_loader

# Usage
train_loader, valid_loader = get_loaders(
    df, tokenizer, CFG.img_size, CFG.batch_size, CFG.max_len, tokenizer.PAD_code
)



# for i, batch in enumerate(valid_loader):
#     if batch is None:
#         continue
#     images, labels, bboxes = batch
#     print(f"Batch {i+1}")
#     print("Images:", images.shape)
#     print("Labels:", labels)
#     print("BBoxes:", bboxes)
#     break



encoder = Encoder(model_name=CFG.model_name, pretrained=True, out_dim=256)
decoder = Decoder(vocab_size=tokenizer.vocab_size,
                  encoder_length=CFG.num_patches, dim=256, num_heads=8, num_layers=6)
model = EncoderDecoder(encoder, decoder)
model.to(CFG.device)

def train_epoch(model, train_loader, optimizer, lr_scheduler, criterion, logger=None):
    model.train()
    loss_meter = AvgMeter()
    tqdm_object = tqdm(train_loader, total=len(train_loader))
    
    for x, y in tqdm_object:
        x, y = x.to(CFG.device, non_blocking=True), y.to(CFG.device, non_blocking=True)
        
        y_input = y[:, :-1]
        y_expected = y[:, 1:]
        
        preds = model(x, y_input)
        loss = criterion(preds.reshape(-1, preds.shape[-1]), y_expected.reshape(-1))
        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()


        if lr_scheduler is not None:
            lr_scheduler.step()
        
        loss_meter.update(loss.item(), x.size(0))
        
        lr = get_lr(optimizer)
        tqdm_object.set_postfix(train_loss=loss_meter.avg, lr=f"{lr:.6f}")
        
        if logger is not None:
            logger.log({"train_step_loss": loss_meter.avg, 'lr': lr})
    
    # Moved this outside the loop for demonstration purposes
    # if CFG.debug:  # Assuming you have a debug flag in CFG
    #     most_probable_tokens = torch.argmax(preds, dim=-1).cpu().numpy()  # Moved to CPU and converted to numpy
    #     tokenizer = Tokenizer(num_classes=6, num_bins=224, width=224, height=224)
        
    #     for i in range(min(5, most_probable_tokens.shape[0])):  # Show for first 5 images in the last batch
    #         sequence = most_probable_tokens[i]
    #         labels, bboxes = tokenizer.decode(sequence)
    #         print(f"Image {i+1}:")
    #         print("Labels:", labels)
    #         print("Bounding Boxes:", bboxes)
    
    return loss_meter.avg


def generate(model, x, tokenizer, max_len=50, top_k=0, top_p=1):
    x = x.to(CFG.device)
    batch_preds = torch.ones(x.size(0), 1).fill_(tokenizer.BOS_code).long().to(CFG.device)
    confs = []
    
    if top_k != 0 or top_p != 1:
        sample = lambda preds: torch.softmax(preds, dim=-1).multinomial(num_samples=1).view(-1, 1)
    else:
        sample = lambda preds: torch.softmax(preds, dim=-1).argmax(dim=-1).view(-1, 1)
        
    with torch.no_grad():
        for i in range(max_len):
            preds = model.predict(x, batch_preds)
            ## If top_k and top_p are set to default, the following line does nothing!
            preds = top_k_top_p_filtering(preds, top_k=top_k, top_p=top_p)
            if i % 4 == 0:
                confs_ = torch.softmax(preds, dim=-1).sort(axis=-1, descending=True)[0][:, 0].cpu()
                confs.append(confs_)
            preds = sample(preds)
            batch_preds = torch.cat([batch_preds, preds], dim=1)
    
    return batch_preds.cpu(), confs


from torchmetrics.detection.mean_ap import MeanAveragePrecision


def valid_epoch(model, valid_loader, criterion):
    model.eval()
    loss_meter = AvgMeter()
    tqdm_object = tqdm(valid_loader, total=len(valid_loader))

    mean_average_precision = MeanAveragePrecision()

    with torch.no_grad():
        for x, y in tqdm_object:
            x, y = x.to(CFG.device, non_blocking=True), y.to(CFG.device, non_blocking=True)
            
            y_input = y[:, :-1]
            y_expected = y[:, 1:]
            
            preds, confs = generate(model, x, tokenizer, max_len=CFG.generation_steps, top_k=0, top_p=1)
            # Convert preds to floating-point before reshaping and passing to loss function
            preds = preds.float()
            loss = criterion(preds.reshape(-1, preds.shape[-1]), y_expected.reshape(-1))
            loss_meter.update(loss.item(), x.size(0))

            # Decoding predictions and ground truths
            preds_decoded = [tokenizer.decode(pred) for pred in preds]
            gt_decoded = [tokenizer.decode(gt) for gt in y_expected]

            # Format predictions and ground truths for torchmetrics
            for pred_decoded, gt_decoded_item, conf in zip(preds_decoded, gt_decoded, confs):
                labels, bboxes = pred_decoded
                gt_labels, gt_bboxes = gt_decoded_item

                preds_formatted = {
                    "boxes": torch.tensor(bboxes).to(CFG.device), 
                    "labels": torch.tensor(labels).to(CFG.device), 
                    "scores": torch.tensor(conf).to(CFG.device)  # Use actual confidence scores here
                }
                targets_formatted = {
                    "boxes": torch.tensor(gt_bboxes).to(CFG.device), 
                    "labels": torch.tensor(gt_labels).to(CFG.device)
                }
                
                mean_average_precision.update([preds_formatted], [targets_formatted])

    # Compute final mAP score
    final_map = mean_average_precision.compute()
    print(f"Validation mAP: {final_map}")

    return loss_meter.avg, final_map










# Log hyperparameters
# wandb.config.update({
#     "max_len": CFG.max_len,
#     "img_size": CFG.img_size,
#     "batch_size": CFG.batch_size,
#     "epochs": CFG.epochs,
#     "model_name": CFG.model_name,
#     "lr": CFG.lr,
#     "weight_decay": CFG.weight_decay
# })

def train_eval(model, train_loader, valid_loader, criterion, optimizer, lr_scheduler, step, logger):
    best_loss = float('inf')
    
    for epoch in range(CFG.epochs):
        print(f"Epoch {epoch + 1}")
        
        train_loss = train_epoch(model, train_loader, optimizer, 
                                 lr_scheduler if step == 'batch' else None, 
                                 criterion)
        
        valid_loss = valid_epoch(model, valid_loader, criterion)
        print(f"Valid loss: {valid_loss:.3f}")
        
        # Log metrics to WandB
        #wandb.log({"train_loss": train_loss, "valid_loss": valid_loss})
        
        if step == 'epoch':
            pass


        if valid_loss < best_loss:
            best_loss = valid_loss
            save_path = '/home/achazhoor/Documents/workspace/pix_2_seq/model_weights/best_valid_loss.pth'
            torch.save(model.state_dict(), save_path)
            #.save(save_path)  # Save model to WandB
            print("Saved Best Model")
        
        if epoch == CFG.epochs - 1:
            save_path = '/home/achazhoor/Documents/workspace/pix_2_seq/model_weights/last_model.pth'
            torch.save(model.state_dict(), save_path)
            print("Saved Last Model")

        if logger is not None:
            logger.log({
                "train_loss": train_loss,
                "valid_loss": valid_loss,
                "epoch": epoch
            })
        


import torch
import torch.nn as nn
import torch.nn.functional as F

class FocalLoss(nn.Module):
    def __init__(self, alpha=1, gamma=2, ignore_index=None):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.ignore_index = ignore_index

    def forward(self, inputs, targets):
        ce_loss = F.cross_entropy(inputs, targets, reduction='none', ignore_index=self.ignore_index)
        pt = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - pt)**self.gamma * ce_loss
        return focal_loss.mean()



optimizer = torch.optim.AdamW(model.parameters(), lr=CFG.lr, weight_decay=CFG.weight_decay)

num_training_steps = CFG.epochs * (len(train_loader.dataset) // CFG.batch_size)
num_warmup_steps = int(0.1 * num_training_steps)
lr_scheduler = get_linear_schedule_with_warmup(optimizer,
                                               num_training_steps=num_training_steps,
                                               num_warmup_steps=num_warmup_steps)

criterion = nn.CrossEntropyLoss(ignore_index=CFG.pad_idx) #alpha=1, gamma=2, 

train_eval(model,
           train_loader,
           valid_loader,
           criterion,
           optimizer,
           lr_scheduler=lr_scheduler,
           step='batch',
           logger=None)

